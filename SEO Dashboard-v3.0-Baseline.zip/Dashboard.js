/***************************************************
 * EXECUTIVE DASHBOARD
 ***************************************************/

function generateDashboard(){

  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);

  const dashboard = ss.getSheetByName(CONFIG.DASHBOARD_SHEET);

  dashboard.clear();

  dashboard.getRange("A1").setValue("SEO DASHBOARD v3.0");

  dashboard.getRange("A3").setValue("Generated");

  dashboard.getRange("B3").setValue(new Date());

  dashboard.getRange("A5").setValue("EXECUTIVE KPI");

}